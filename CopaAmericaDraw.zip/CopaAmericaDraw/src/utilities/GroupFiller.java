package utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import groups.Group;
import pots.Pot;
import teams.Team;

public class GroupFiller {

	// fills groups until they are full or no longer able to add teams from a division that will violate the draw's requirements
	public void fillGroup(Pot pot, Group groupA, Group groupB, Group groupC, Group groupD) {
		
		List<Team> teamsInPot = pot.getPot();
		
		List<Group> listOfGroups = new ArrayList<>();
		listOfGroups.add(groupA);
		listOfGroups.add(groupB);
		listOfGroups.add(groupC);
		listOfGroups.add(groupD);
		
		Scanner s = new Scanner(System.in);
		boolean simulate = false;
		boolean groupADone = false, groupBDone = false, groupCDone = false, groupDDone = false;
		int cont = 0;
		int potSize = teamsInPot.size();
		Random random = new Random();
		int sel;
		Team curTeam;
		
		// variable to keep track of what group may have 2 concacaf teams already (useful for pot 4 draw checks)
		int groupForConmebol = 0;
		
		if (pot.getPotNum() == 4) {
			
			for (Group g : listOfGroups) {
				
				if (g.numOfConcacaf() == 2) {
					groupForConmebol = g.getGroupNum(); //get group number
				}
				
			}
			
		}
		
		
		for (int i = 0; i < potSize; i++) {
			
			s.nextLine();
			
			sel = random.nextInt(teamsInPot.size());
			
			curTeam = teamsInPot.get(sel);
			
			System.out.println(curTeam.getName() + " has been selected.");
			
			if (groupForConmebol == 0) {
				
				// check if i is 2. if it is, we have selected third team which decides the legality of our next placement.
				// when in this if statement, there is 1 conc. team in 3 groups. On the third team selected, if 2 conc. teams have already been placed into a group with
				// another conc. team present, AND the team drawn 3rd from the final pot is also a conc. team, it MUST go to the group with 0 conc. teams. 
				// Reason: if 3 groups had 1 conc. team going into the 4th pot draw and all 3 conc. teams in pot 4 were drawn in those 3 groups, the final conm. team in pot 4 will
				// be forced into the group without a conc. team, violating the max 3 conm. teams in a group rule.
				
				if (pot.getPotNum() == 4) { // only check this condition if we are in pot 4
					
					if (i == 2) { // if we have drawn the third team
						
						// check if curTeam is conmebol or concacaf and check if group has 1 or 0 concacaf teams already for each option, adding when the rule is respected
						if (curTeam.getDivision() == "CONCACAF") {
							
							
							
							
							if (groupADone == false) {
								if (groupA.numOfConcacaf() != 1) {
									groupA.addToGroup(curTeam);
									cont = 1;
								}
							}
							if (groupBDone == false) {
								if (groupB.numOfConcacaf() != 1) {
									groupB.addToGroup(curTeam);
									cont = 1;
								}
							} 
							if (groupCDone == false) {
								if (groupC.numOfConcacaf() != 1) {
									groupC.addToGroup(curTeam);
									cont = 1;
								}
							}
							if (groupDDone == false) {
								if (groupD.numOfConcacaf() != 1) {
									groupD.addToGroup(curTeam);
									cont = 1;
								}
							}
							
							
						} else {
							
							if (groupADone == false) {
								if (groupA.numOfConcacaf() == 1) {
									groupA.addToGroup(curTeam);
									cont = 1;
								}
							}
							if (groupBDone == false) {
								if (groupB.numOfConcacaf() == 1) {
									groupB.addToGroup(curTeam);
									cont = 1;
								}
							}
							if (groupCDone == false) {
								if (groupC.numOfConcacaf() == 1) {
									groupC.addToGroup(curTeam);
									cont = 1;
								}
							}
							if (groupDDone == false) {
								if (groupD.numOfConcacaf() == 1) {
									groupD.addToGroup(curTeam);
									cont = 1;
								}
							}
							
							
							
							
						}
						
						
						
					}
					
				}
				
				
				
				
				// if not added to group A yet
				if (groupADone == false && cont == 0) {
					
					if (groupA.addToGroup(curTeam) == true) {
						
					} else {
						groupADone = true;
						cont = 1;
					}
				
				}
				
				if (groupBDone == false && cont == 0) {
					
					if (groupB.addToGroup(curTeam) == true) {

					} else {
						groupBDone = true;
						cont = 1;
					}
					
				}
				
				if (groupCDone == false && cont == 0) {
					
					if (groupC.addToGroup(curTeam) == true) {
						
					} else {
						groupCDone = true;
						cont = 1;
					}
					
				}
				
				if (groupDDone == false && cont == 0) {
					
					if (groupD.addToGroup(curTeam) == true) {
						
					} else {
						groupDDone = true;
						cont = 1;
					}
					
				}
					
				cont = 0;
				teamsInPot.remove(curTeam);
				
			} else {
				
				if (curTeam.getDivision() == "CONCACAF") {
					
					// if not added to group A yet
					if (groupADone == false && cont == 0) {
						
						if (groupA.addToGroup(curTeam) == true) {
							
						} else {
							groupADone = true;
							cont = 1;
						}
					
					}
					
					if (groupBDone == false && cont == 0) {
						
						if (groupB.addToGroup(curTeam) == true) {

						} else {
							groupBDone = true;
							cont = 1;
						}
						
					}
					
					if (groupCDone == false && cont == 0) {
						
						if (groupC.addToGroup(curTeam) == true) {
							
						} else {
							groupCDone = true;
							cont = 1;
						}
						
					}
					
					if (groupDDone == false && cont == 0) {
						
						if (groupD.addToGroup(curTeam) == true) {
							
						} else {
							groupDDone = true;
							cont = 1;
						}
						
					}
						
					cont = 0;
					teamsInPot.remove(curTeam);
					
				} else {
					
					// iterate thru and place in group with 2 concacaf teams
					
					// use group for conmebol to decode which group to add curTeam to then assign proper variable values
					if (groupForConmebol == 1) {
						groupA.addToGroup(curTeam);
						groupADone = true;
						teamsInPot.remove(curTeam);
					} else if (groupForConmebol == 2) {
						groupB.addToGroup(curTeam);
						groupBDone = true;
						teamsInPot.remove(curTeam);
					} else if (groupForConmebol == 3) {
						groupC.addToGroup(curTeam);
						groupCDone = true;
						teamsInPot.remove(curTeam);
					} else {
						groupD.addToGroup(curTeam);
						groupDDone = true;
						teamsInPot.remove(curTeam);
					}
					
					
					
					
				}
				
				
				
			}
			
			
			
		}
		
	}	

}
