package utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import groups.Group;
import pots.Pot;
import teams.Team;

public class GroupFiller {

	// fills groups until they are full or no longer able to add teams from a divison that will violate the draw's requirements
	public void fillGroup(List<Team> teamsInPot, Group groupA, Group groupB, Group groupC, Group groupD) {
		
		Scanner s = new Scanner(System.in);
		boolean simulate = false;
		boolean groupADone = false, groupBDone = false, groupCDone = false, groupDDone = false;
		int cont = 0;
		int potSize = teamsInPot.size();
		Random random = new Random();
		int sel;
		Team curTeam;
		
		for (int i = 0; i < potSize; i++) {
			
			s.nextLine();
			
			sel = random.nextInt(teamsInPot.size());
			
			curTeam = teamsInPot.get(sel);
			
			System.out.println(curTeam.getName() + " has been selected.");
			
			// if not added to group A yet
			if (groupADone == false && cont == 0) {
				
				if (groupA.addToGroup(curTeam) == true) {
					
				} else {
					groupADone = true;
					cont = 1;
				}
			
			}
			
			if (groupBDone == false && cont == 0) {
				
				if (groupB.addToGroup(curTeam) == true) {

				} else {
					groupBDone = true;
					cont = 1;
				}
				
			}
			
			if (groupCDone == false && cont == 0) {
				
				if (groupC.addToGroup(curTeam) == true) {
					
				} else {
					groupCDone = true;
					cont = 1;
				}
				
			}
			
			if (groupDDone == false && cont == 0) {
				
				if (groupD.addToGroup(curTeam) == true) {
					
				} else {
					groupDDone = true;
					cont = 1;
				}
				
			}
				
			cont = 0;
			teamsInPot.remove(curTeam);
			
		}
		
	}	
}
