package utilities;

import java.util.List;

import pots.Pot;
import teams.Team;

public class PotFiller {
	
	// take list of teams and add them into their respective pots
	public void fillPots(List<Team> listOfTeams, Pot pot1, Pot pot2, Pot pot3, Pot pot4) {
		
		for (Team team : listOfTeams) {
			if (team.getPot() == 1) {
				// add to pot 1
				pot1.addToPot(team);
			} else if (team.getPot() == 2) {
				pot2.addToPot(team);
			} else if (team.getPot() == 3) {
				pot3.addToPot(team);
			} else {
				pot4.addToPot(team);
			}
		}
		
	}

}
