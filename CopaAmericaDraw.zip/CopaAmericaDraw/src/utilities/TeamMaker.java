package utilities;

import java.util.ArrayList;
import java.util.List;

import teams.Team;

public class TeamMaker {
	
	private static TeamMaker instance = null;
	private List<Team> listOfTeams = new ArrayList<>();
	
	private TeamMaker TeamMaker() {
		return new TeamMaker();
	}
	
	public static TeamMaker getInstance() {
		if (instance == null) {
			return new TeamMaker();
		}
		return instance;
	}
	
	// creates all teams to play in the tournament and returns a list of them
	public List<Team> createTeams() {
		
		// Create pot 1 teams
		Team argentina = new Team("Argentina", "CONMEBOL", 1);
		Team brazil = new Team("Brazil", "CONMEBOL", 1);
		Team usa = new Team("United States of America", "CONCACAF", 1);
		Team mexico = new Team("Mexico", "CONCACAF", 1);
		
		// Create pot 2 teams
		Team uruguay = new Team("Uruguay", "CONMEBOL", 2);
		Team colombia = new Team("Colombia", "CONMEBOL", 2);
		Team peru = new Team("Peru", "CONMEBOL", 2);
		Team ecuador = new Team("Ecuador", "CONMEBOL", 2);
		
		// Create pot 3 teams
		Team chile = new Team("Chile", "CONMEBOL", 3);
		Team panama = new Team("Panama", "CONCACAF", 3);
		Team venezuela = new Team("Venezuela", "CONMEBOL", 3);
		Team paraguay = new Team("Paraguay", "CONMEBOL", 3);
		
		// Create pot 4 teams
		Team jamaica = new Team("Jamaica", "CONCACAF", 4);
		Team bolivia = new Team("Bolivia", "CONMEBOL", 4);
		Team canada = new Team("Canada", "CONCACAF", 4);
		Team costaRica = new Team("Costa Rica", "CONCACAF", 4);
		
		// Add pot 1 teams
		listOfTeams.add(argentina);
		listOfTeams.add(brazil);
		listOfTeams.add(usa);
		listOfTeams.add(mexico);
		
		// Add pot 2 teams
		listOfTeams.add(uruguay);
		listOfTeams.add(colombia);
		listOfTeams.add(peru);
		listOfTeams.add(ecuador);
		
		// Add pot 3 teams
		listOfTeams.add(chile);
		listOfTeams.add(panama);
		listOfTeams.add(venezuela);
		listOfTeams.add(paraguay);
		
		// Add pot 4 teams
		listOfTeams.add(jamaica);
		listOfTeams.add(bolivia);
		listOfTeams.add(canada);
		listOfTeams.add(costaRica);
		
		// return list of all teams in tournament
		return listOfTeams; 
	}
	

}
