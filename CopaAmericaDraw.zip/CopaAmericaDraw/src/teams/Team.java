package teams;

public class Team {
	
	private final String name;
	private final String division;
	private final int pot;
	
	public Team(String name, String division, int pot) {
		this.name = name;
		this.division = division;
		this.pot = pot;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDivision() {
		return division;
	}
	
	public int getPot() {
		return pot;
	}	

}
