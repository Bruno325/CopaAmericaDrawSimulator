package groups;

import java.util.ArrayList;
import java.util.List;

import teams.Team;

public class GroupD extends Group {

	private List<Team> teamsInGroup = new ArrayList<>();
	private boolean cantAdd = false;
	private int numOfConmebol = 0;
	private int numOfConcacaf = 0;
	private int groupNum = 4; // group D = group 4

	@Override
	public boolean addToGroup(Team team) {
		
		cantAdd = false;
		
		if (teamsInGroup.size() == 4) {
			cantAdd = true;
		} 
		if (numOfConmebol == 3) {
			
			if (team.getDivision().equals("CONMEBOL")) {
				cantAdd = true;
			}
			
		} 
		if (numOfConcacaf == 2) {
			if (team.getDivision().equals("CONCACAF")) {
				cantAdd = true;
			}
		}
		
		if (cantAdd) {
			System.out.println("Can't add to group D");
		} else {
			
			if (team.getDivision() == "CONMEBOL") {
				numOfConmebol++;
			} else {
				numOfConcacaf++;
			}
			
			System.out.println(team.getName() + " has been added to Group D.");
			teamsInGroup.add(team);
		}
			
		return cantAdd;
		
	}

	@Override
	public void printGroup() {
		groupPrinter.printGroup(teamsInGroup, "D");
	}

	@Override
	public int numOfConcacaf() {
		// TODO Auto-generated method stub
		return numOfConcacaf;
	}

	@Override
	public int getGroupNum() {
		// TODO Auto-generated method stub
		return groupNum;
	}
	
}
