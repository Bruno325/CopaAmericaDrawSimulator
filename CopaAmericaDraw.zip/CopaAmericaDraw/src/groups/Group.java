package groups;

import java.util.List;

import printers.GroupPrinter;
import teams.Team;

public abstract class Group {
	
	protected GroupPrinter groupPrinter = new GroupPrinter();
	
	// used to add team to group
	public abstract boolean addToGroup(Team team);
	
	// used to print list of teams in group
	public abstract void printGroup();
	
	// returns number of concacaf teams present in group (useful for pot 4 draw checks)
	public abstract int numOfConcacaf();
	
	// return an integer 1-4 corresponding to the group letters A-D
	public abstract int getGroupNum();

}
