package backEnd;

import java.util.List;

import teams.Team;
import utilities.GroupFiller;
import utilities.PotFiller;
import utilities.TeamMaker;
import pots.*;
import groups.*;

public class Draw {
	
	public void startDraw() {
		
		/*
		 * 1. Create all teams
		 * 2. Create 4 pots and populate them
		 * 3. Begin the draw
		 */
		
		// Create list of all teams
		TeamMaker aTeamMaker = new TeamMaker();
		List<Team> listOfTeams = aTeamMaker.createTeams();
		
		// Create pots 1-4
		Pot pot1 = new Pot1();
		Pot pot2 = new Pot2();
		Pot pot3 = new Pot3();
		Pot pot4 = new Pot4();
		
		// fill all 4 pots
		PotFiller aPotFiller = new PotFiller();
		aPotFiller.fillPots(listOfTeams, pot1, pot2, pot3, pot4);
		
		// create groups A-D
		Group groupA = new GroupA();
		Group groupB = new GroupB();
		Group groupC = new GroupC();
		Group groupD = new GroupD();
		
		/*
		 * begin the draw
		 * 
		 * 1. give prompt for user's possible inputs
		 * 2. wait for user input
		 * 3. if draw, show the team and where they ended up getting placed (use linked list to go thru the groups?)
		 * 4. if simulate, u need to automatically be able to draw the teams
		 */
		
		// HAVE ANOTHER CLASS TO PRINT THE RULES
		System.out.println("Welcome to the Copa America 2024 Draw!");
		System.out.println("There are four pots with four teams in each of them based on their tournament accomplishments or fifa rankings.");
		System.out.println("Pot 1 contains reigning Copa America and Gold Cup winners, as well as the highest ranked CONCACAF and CONMEBOL teams based on the 2023 FIFA World Rankings.");
		System.out.println("The remaining teams were placed in Pots 2-4 based on their rankings in the 2023 Fifa World Rankings, with 2 CONCACAF teams from a play-in match to be played in March automatically placed in Pot 4.");
		System.out.println("Teams will be chosen in order of their pots. Every team in Pot 1 will be selected and placed in the first available group that does not already contain a team from Pot 1.");
		System.out.println("The same rules will follow for the rest of the pots. They will be placed in the first available group.");
		System.out.println("The only restriction on a team's eligibility for being placed in a group is that one group may not have more than 3 CONMEBOL teams or more than 2 CONCACAF teams.");
		System.out.println("If a group were to have more than 3 CONMEBOL or 2 CONCACAF teams, that team will be placed in the next available group.");
		System.out.println("Here are the teams in each of the four pots...\n");
		
		// display the teams in the 4 pots
		pot1.printPot();
		pot2.printPot();
		pot3.printPot();
		pot4.printPot();
		
		// HAVE SAME CLASS THAT PRINTS RULES PRINT THESE INSTRUCTIONS
		System.out.println("\nTo draw teams, you may press 'enter' on your keyboard and you will be alerted of a team's selection and placement in their group.");

		System.out.println("Let's begin the Copa America 2024 Draw!\n");
		
		// have the scanner object class thing to get user's input and keep looping til everything is done
		GroupFiller aGroupFiller = new GroupFiller();
		aGroupFiller.fillGroup(pot1, groupA, groupB, groupC, groupD);
		aGroupFiller.fillGroup(pot2, groupA, groupB, groupC, groupD);
		aGroupFiller.fillGroup(pot3, groupA, groupB, groupC, groupD);
		aGroupFiller.fillGroup(pot4, groupA, groupB, groupC, groupD);
		
		System.out.println("\n");
		groupA.printGroup();
		groupB.printGroup();
		groupC.printGroup();
		groupD.printGroup();
		
		System.out.println("That concludes the Copa America 2024 Draw. Thank you and good luck!");
		
	}

}
