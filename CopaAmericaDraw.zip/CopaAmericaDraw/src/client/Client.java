/*
 * https://www.sambafoot.com/news/key-points-of-the-2024-copa-america-draw-seeded-teams-draw-pots-and-rules
 * 
 * last paragraph gives the constraints for the group (no more than 3 conmebol teams, no more than 2 concacaf teams / group
 */
package client;

import backEnd.Draw;

public class Client {
	
	public static void main(String[] args) {
		// run the draw
		Draw theDraw = new Draw();
		theDraw.startDraw();
	}
	
}
