package pots;

import java.util.ArrayList;
import java.util.List;

import teams.Team;

public class Pot2 extends Pot {

	private List<Team> teamsInGroup = new ArrayList<>();
	private int potNum = 2;
	
	@Override
	public int getPotNum() {
		return potNum;
	}
	
	@Override
	public void addToPot(Team team) {
		teamsInGroup.add(team);
	}

	@Override
	public void printPot() {
		// pass the teamsInGroup set to PotPrinter
		potPrinter.printPot(teamsInGroup, 2);
	}

	@Override
	public List<Team> getPot() {
		return teamsInGroup;
	}

}
