package pots;

import java.util.List;

import printers.PotPrinter;
import teams.Team;

public abstract class Pot {
	
	protected PotPrinter potPrinter = new PotPrinter();
	
	// adds team to pot
	public abstract void addToPot(Team team);
	
	// prints list of teams in pot
	public abstract void printPot();
	
	// gets list of teams in pot
	public abstract List<Team> getPot();

}
