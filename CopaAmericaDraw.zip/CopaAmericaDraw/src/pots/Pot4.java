package pots;

import java.util.ArrayList;
import java.util.List;

import teams.Team;

public class Pot4 extends Pot {
	
	private List<Team> teamsInGroup = new ArrayList<>();
	
	@Override
	public void addToPot(Team team) {
		teamsInGroup.add(team);
	}

	@Override
	public void printPot() {
		// pass the teamsInGroup set to PotPrinter
		potPrinter.printPot(teamsInGroup, 4);
	}

	@Override
	public List<Team> getPot() {
		return teamsInGroup;
	}

}
