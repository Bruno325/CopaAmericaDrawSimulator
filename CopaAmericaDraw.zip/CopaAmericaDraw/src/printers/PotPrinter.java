package printers;

import java.util.List;

import teams.Team;

public class PotPrinter {

	public void printPot(List<Team> teamsInPot, int potNum) {
		
		System.out.println("--- POT " + potNum + " ---");
		
		int i = 1;
		
		// print the four teams in 'teamsInPot' (the teams in the 'potNum'th pot)
		for (Team team : teamsInPot) {
			
			if (i < teamsInPot.size()) { // instead of i < 4, do list.size
				System.out.print(team.getName() + ", ");
			} else {
				System.out.print(team.getName() + "\n");
			}
			
			i++;
		}
		
	}
	
}
