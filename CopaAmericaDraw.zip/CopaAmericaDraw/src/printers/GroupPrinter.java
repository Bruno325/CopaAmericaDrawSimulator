package printers;

import java.util.List;

import teams.Team;

public class GroupPrinter {
	
	public void printGroup(List<Team> teamsInGroup, String group) {
		
		System.out.println("=== GROUP " + group + " ===");
		
		int i = 1;
		
		// print the four teams in 'group'
		for (Team team : teamsInGroup) {
			
			if (i < teamsInGroup.size()) {
				System.out.println(team.getName() + ", ");
			} else {
				System.out.println(team.getName() + "\n");
			}
			
			i++;
		}
		
	}

}
